Luis Daniel Medina Cazarez A01651070
Fernando Martin Garcia Del Angel - A01334390
Jorge Espinosa Lara A01337002
Armando Hern�ndez Vargas A01334836